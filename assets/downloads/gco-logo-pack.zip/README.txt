Georgia Center for Opportunity logo pack (November 2026)

original/  GCO's official logo files, exactly as supplied.
svg/       Vector versions traced from the official files. Use these where you can.
png/       600px and 2000px PNGs made from the SVGs.

Layouts: centered with lines (primary), centered no lines, left aligned, long horizontal.
Colors: navy #084975 and gold #FBB040. White versions are for navy, slate and dark photos.
Primary file names: full-color, reverse (white with gold), one-color (navy), white (all white).

Clear space = height of the O in Opportunity. Minimum width 160px / 1.5in.
Never place the logo over the ring ("O") artwork. Full guidance: https://brand.foropportunity.org/#logo
