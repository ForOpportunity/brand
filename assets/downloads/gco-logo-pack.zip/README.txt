For Opportunity / Georgia Center for Opportunity logo pack (interim redraw, Oct 2026).
full-color: white and off-white backgrounds. reverse: slate and dark photos. one-color: single ink. white: busy dark photos.
Clear space = height of the O in Opportunity. Minimum width 160px / 1.5in.
