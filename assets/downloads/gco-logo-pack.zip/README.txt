Georgia Center for Opportunity logo pack (stacked logo, Nov 2026).
Vectors traced from the official logo artwork on foropportunity.org.
full-color: white and off-white backgrounds. reverse: slate and dark photos. one-color: single ink. white: busy dark photos.
Clear space = height of the O in Opportunity. Minimum width 160px / 1.5in.
