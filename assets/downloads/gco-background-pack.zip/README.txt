GCO background art.
source/: the ring (for slate, kept very light: 26% to 5% white) and the arrow (for light), as vectors plus the original website PNGs.
svg/ and png/: ready-made crops in 1:1, 4:5, 9:16 and 16:9.
Use one shape per piece, always cropped by the frame edge. Do not recolor, rotate, flip or tile.
